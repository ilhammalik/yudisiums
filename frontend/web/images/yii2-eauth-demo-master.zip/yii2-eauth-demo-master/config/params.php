<?php

return array(
	'adminEmail' => 'admin@example.com',
);
